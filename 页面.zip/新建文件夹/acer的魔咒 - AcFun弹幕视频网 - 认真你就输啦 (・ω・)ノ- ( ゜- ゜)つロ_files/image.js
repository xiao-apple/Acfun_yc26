(function () {

    var utils = UM.utils,
        browser = UM.browser,
        Base = {
        checkURL: function (url) {
            if(!url)    return false;
            url = utils.trim(url);
            if (url.length <= 0) {
                return false;
            }
            if (url.search(/http:\/\/|https:\/\//) !== 0) {
                url += 'http://';
            }

            url=url.replace(/\?[\s\S]*$/,"");

            if (!/(.gif|.jpg|.jpeg|.png)$/i.test(url)) {
                return false;
            }
            return url;
        },
        getAllPic: function (sel, $w, editor) {
            var me = this,
                arr = [],
                $imgs = $(sel, $w);

            $.each($imgs, function (index, node) {
                $(node).removeAttr("width").removeAttr("height");

//                if (node.width > editor.options.initialFrameWidth) {
//                    me.scale(node, editor.options.initialFrameWidth -
//                        parseInt($(editor.body).css("padding-left"))  -
//                        parseInt($(editor.body).css("padding-right")));
//                }

                return arr.push({
                    _src: node.src,
                    src: node.src
                });
            });

            return arr;
        },
        scale: function (img, max, oWidth, oHeight) {
            var width = 0, height = 0, percent, ow = img.width || oWidth, oh = img.height || oHeight;
            if (ow > max || oh > max) {
                if (ow >= oh) {
                    if (width = ow - max) {
                        percent = (width / ow).toFixed(2);
                        img.height = oh - oh * percent;
                        img.width = max;
                    }
                } else {
                    if (height = oh - max) {
                        percent = (height / oh).toFixed(2);
                        img.width = ow - ow * percent;
                        img.height = max;
                    }
                }
            }

            return this;
        },
        close: function ($img) {

            $img.css({
                top: ($img.parent().height() - $img.height()) / 2,
                left: ($img.parent().width()-$img.width())/2
            }).prev().on("click",function () {

                if ( $(this).parent().remove().hasClass("edui-image-upload-item") ) {
                    //显示图片计数-1
                     Upload.showCount--;
                     Upload.updateView();
                }

            });

            return this;
        },
        createImgBase64: function (img, file, $w) {
            if (browser.webkit) {
                //Chrome8+
                img.src = window.webkitURL.createObjectURL(file);
            } else if (browser.gecko) {
                //FF4+
                img.src = window.URL.createObjectURL(file);
            } else {
                //实例化file reader对象
                var reader = new FileReader();
                reader.onload = function (e) {
                    img.src = this.result;
                    $w.append(img);
                };
                reader.readAsDataURL(file);
            }
        },
        callback: function (editor, $w, url, state) {

            if (state == "SUCCESS") {
                //显示图片计数+1
                Upload.showCount++;
                var $img = $("<img src='" + editor.options.imagePath + url + "' class='edui-image-pic' />"),
                    $item = $("<div class='edui-image-item edui-image-upload-item'><div class='edui-image-close'></div></div>").append($img);

                if ($(".edui-image-upload2", $w).length < 1) {
                    $(".edui-image-content", $w).append($item);

                    Upload.render(".edui-image-content", 2)
                        .config(".edui-image-upload2");
                } else {
                    $(".edui-image-upload2", $w).before($item).show();
                }

                $img.on("load", function () {
                    Base.scale(this, 120);
                    Base.close($(this));
                    $(".edui-image-content", $w).focus();
                });

            } else {
                currentDialog.showTip( state );
                window.setTimeout( function () {

                    currentDialog.hideTip();

                }, 3000 );
            }

            Upload.toggleMask();

        }
    };
var localUpload;
var UploadQiniu = {
	init :function (btnId,onLoadedBack,errorCallBack){
            console.log(1111);
            console.log(window.QiniuJsSDK);
    		var qiniu = new window.QiniuJsSDK();
            localUpload = qiniu.uploader({
                runtimes: 'html5,flash,html4',
                browse_button: btnId,
                //uptoken: 'jkVZqwN195Da4xtSPZ0lwnlj2cgBq07sPZyTBwvq:eXsSg8H0VDuIafoX6Z5daZK3nfk=:eyJzY29wZSI6InRlc3QtZG91dyIsImRlYWRsaW5lIjoxNDc5Mzg1MzgzfQ==',
                uptoken_url: 'http://www.acfun.cn/appcms/api/qiniu/uptoken',
                domain: 'http://imgs.aixifan.com/',
                max_file_size: '3mb',
                flash_swf_url: 'flash/Moxie.swf',
                dragdrop: false,
                chunk_size: '3mb',
                auto_start: true,
                init: {
                    'FilesAdded': function (up, files) {
                        window.plupload.each(files, function (file) {
                            // 文件添加进队列后,处理相关的事情
                        });
                    },
                    'BeforeUpload': function (up, file) {
                        // 每个文件上传前,处理相关的事情

                    },
                    'FileUploaded': function (up, file, info) {
                        // 上传完成后，刷新展示数据
                        // 
                        var domain = up.getOption('domain'),
                            res = JSON.parse(info),
                            sourceLink = domain + res.key;
                           
                            onLoadedBack(sourceLink);
                           
                    },
                    'Error': function (up, err, errTip) {
                        //上传出错时,展示错误消息
                        //
                        var filename = '';
                        if(err && err.file && err.file.name){
                            filename = err.file.name;
                        }
                        if(err){
                            if(err.code === -600) {
                                errorCallBack(" 上传文件：" + filename + "文件过大,请压缩至3M以下上传！");
                            }else if(err.code === -601 || err.code === -701){
                                errorCallBack(" 上传文件：" + filename + ",文件格式错误!");
                            }else{
                                 errorCallBack(" 上传文件：" + filename +　":" + errTip);
                            }
                        }
        				
                       
                        
                    },
                    'Key': function (up, file) {
                        var suffix = '',
                            date = new Date().getTime();
                        if (file.name.indexOf('.') > 0) {
                            suffix = '.' + file.name.split(".").pop();
                        }
                        return 'live/' + date + '/' + date + suffix;
                    }
                },
                filters: {
                    mime_types: [
                        {title: "Image files", extensions: "jpg,jpeg,png"}
                    ]
                }
            });
        return qiniu;
	},

}  

    /*
     * 网络图片
     * */
    var NetWork = {
        init: function (editor, $w) {
            var me = this;

            me.editor = editor;
            me.dialog = $w;

            me.initEvt();
            return me;
        },
        initEvt: function () {
            var me = this,
                url,
                $ele = $(".edui-image-searchTxt", me.dialog);

            $(".edui-image-searchAdd", me.dialog).on("click", function () {
                url = Base.checkURL($ele.val());

                if (url) {

                    $("<img src='" + url + "' class='edui-image-pic' />").on("load", function () {



                        var $item = $("<div class='edui-image-item'><div class='edui-image-close'></div></div>").append(this);

                        $(".edui-image-searchRes", me.dialog).append($item);

                        Base.scale(this, 120);

                        $item.width($(this).width());

                        Base.close($(this));

                        $ele.val("");
                    });
                }
            })
                .hover(function () {
                    $(this).toggleClass("hover");
                });
        },
        onLocalupLoaded:function(url){
        	var me = this;
        	if (url) {

                    $("<img src='" + url + "' class='edui-image-pic' />").on("load", function () {
                        var $item = $("<div class='edui-image-item'><div class='edui-image-close'></div></div>").append(this);

                        $(".edui-image-searchRes", me.dialog).append($item);

                        Base.scale(this, 120);

                        $item.width($(this).width());

                        Base.close($(this));

                    });
                }
        },
        onUploadError:function(err){
        	$.info("error::"+err);
        }

    };


    var $tab = null,
        currentDialog = null;

    UM.registerWidget('image', {
        tpl: "<link rel=\"stylesheet\" type=\"text/css\" href=\"<%=image_url%>image.css\">" +
            // "<script type=\"text/javascript\" src=\"<%=qiniu%>moxie.min.js\"></script>"+
            // "<script type=\"text/javascript\" src=\"<%=qiniu%>plupload.dev.min.js\"></script>"+
            // "<script type=\"text/javascript\" src=\"<%=qiniu%>qiniu.min.js\"></script>"+
            "<div class=\"edui-image-wrapper\">" +
            "<ul class=\"edui-tab-nav\">" +
//            "<li class=\"edui-tab-item edui-active\"><a data-context=\".edui-image-local\" class=\"edui-tab-text\"><%=lang_tab_local%></a></li>" +
            "<li  class=\"edui-tab-item edui-active\"><a data-context=\".edui-image-JimgSearch\" class=\"edui-tab-text\"><%=lang_tab_imgSearch%></a></li>" +
            "</ul>" +
            "<div class=\"edui-tab-content\">" +
//            "<div class=\"edui-image-local edui-tab-pane edui-active\">" +
//            "<div class=\"edui-image-content\"></div>" +
//            "<div class=\"edui-image-mask\"></div>" +
//            "<div class=\"edui-image-dragTip\"><%=lang_input_dragTip%></div>" +
//            "</div>" +
            "<div class=\"edui-image-JimgSearch edui-tab-pane edui-active\">" +
            "<div class=\"edui-image-searchBar\">" +
            "<table><tr><td><input class=\"edui-image-searchTxt\" type=\"text\"></td>" +
            "<td><div class=\"edui-image-searchAdd\"><%=lang_btn_add%></div></td></tr></table>" +
            "</div>" +
            "<div class=\"edui-image-searchRes\"></div>" +
            "</div>" +
            "</div>" +
            "</div>",
        initContent: function (editor, $dialog) {
        	
			//uploadModule.uploaded = uploadModule;
            var lang = editor.getLang('image')["static"],
                opt = $.extend({}, lang, {
                    image_url: UMEDITOR_CONFIG.UMEDITOR_HOME_URL + 'dialogs/image/',
   
                });
                
            if(editor.miniImagetype && editor.miniImagetype==='article'){
                this.tpl = "<link rel=\"stylesheet\" type=\"text/css\" href=\"<%=image_url%>image_article.css\">" +
            // "<script type=\"text/javascript\" src=\"<%=qiniu%>moxie.min.js\"></script>"+
            // "<script type=\"text/javascript\" src=\"<%=qiniu%>plupload.dev.min.js\"></script>"+
            // "<script type=\"text/javascript\" src=\"<%=qiniu%>qiniu.min.js\"></script>"+
            "<div class=\"edui-image-wrapper\">" +
            "<div class=\"edui-tab-content\">" +
            // "<div class=\"edui-image-local edui-tab-pane edui-active\">" +
            // "<div class=\"edui-image-content\"></div>" +
            // "<div class=\"edui-image-mask\"></div>" +
            // "<div class=\"edui-image-dragTip\"><%=lang_input_dragTip%></div>" +
            // "</div>" +
            "<div class=\"edui-image-JimgSearch edui-tab-pane edui-active\">" +
            "<div class=\"edui-image-searchBar\" style=\"widht:90%;\">" +
            "<table class=\"edui-image-continar\"><tr>"+
            "<td><div id=\"edui-image-localupload-btn\" class=\"edui-image-local-btn\">本地上传</div></td>"+
            "<td><div  class=\"edui-image-or\">OR</div></td>"+
            "<td><input class=\"edui-image-searchTxt\" type=\"text\" placeholder=\"请输入URL添加网络图片\"></td>" +
            "<td><div class=\"edui-image-searchAdd\">添加</div></td></tr></table>" +
            "</div>" +
            "<div class=\"edui-image-searchRes\"></div>" +
            "</div>" +
            "</div>" +
            "</div>"
            }
            // Upload.showCount = 0;

            if (lang) {
                var html = $.parseTmpl(this.tpl, opt);
            }

            currentDialog = $dialog.edui();

            this.root().html(html);

        },
        initEvent: function (editor, $w) {
            $tab = $.eduitab({selector: ".edui-image-wrapper"})
                .edui().on("beforeshow", function (e) {
                    e.stopPropagation();
                });

            // Upload.init(editor, $w);
            // 
            var net = NetWork.init(editor, $w);
            if(editor.miniImagetype && editor.miniImagetype==='article'){
                UploadQiniu.init('edui-image-localupload-btn',net.onLocalupLoaded,net.onUploadError)
            }
           
        },
        buttons: {
            'ok': {
                exec: function (editor, $w) {

                    var sel = "",
                    //     index = $tab.activate();

                    // if (index == 0) {
                    //     sel = ".edui-image-content .edui-image-pic";
                    // } else if (index == 1) {
                    //     sel = ".edui-image-searchRes .edui-image-pic";
                    // }
                    sel = ".edui-image-searchRes .edui-image-pic";
                    var list = Base.getAllPic(sel, $w, editor);

                    // if (index != -1) {
                    //     editor.execCommand('insertimage', list);
                    // }
                    editor.execCommand('insertimage', list);
                }
            },
            'cancel': {
                exec: function (editor, $w) {
                   if(editor.miniImagetype && editor.miniImagetype==='article'){
                        if(localUpload){
                           localUpload.destroy(); 
                        }
                    }
                }
            }
        },
        width: 700,
        height: 408
    }, function (editor, $w, url, state) {
        Base.callback(editor, $w, url, state)
    })

})();

